export interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  stock: number;
  category: string;
  imageUrl: string;
}

export interface Customer {
  id: string;
  name: string;
  email: string;
  phone: string;
  address: string;
  joinDate: string;
  totalPurchases: number;
  status: 'نشط' | 'غير نشط';
  notes?: string;
}

export interface SaleItem {
  productId: string;
  productName: string;
  quantity: number;
  unitPrice: number;
  total: number;
}

export interface Sale {
  id: string;
  customerId: string;
  customerName: string;
  items: SaleItem[];
  subtotal: number;
  tax: number;
  total: number;
  date: string;
  status: 'مكتمل' | 'معلق' | 'ملغي';
  paymentMethod: 'نقداً' | 'بطاقة ائتمان' | 'تحويل بنكي';
  notes?: string;
}

export interface SaleFormData {
  customerId: string;
  items: Omit<SaleItem, 'total'>[];
  paymentMethod: Sale['paymentMethod'];
  notes?: string;
}

export interface Report {
  period: string;
  totalSales: number;
  totalRevenue: number;
  averageOrderValue: number;
  topProducts: {
    productId: string;
    productName: string;
    quantity: number;
    revenue: number;
  }[];
  topCustomers: {
    customerId: string;
    customerName: string;
    purchases: number;
    totalSpent: number;
  }[];
}