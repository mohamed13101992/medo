import React, { useState } from 'react';
import { BarChart, Calendar } from 'lucide-react';
import SalesChart from '../components/reports/SalesChart';
import TopProducts from '../components/reports/TopProducts';
import TopCustomers from '../components/reports/TopCustomers';

// بيانات تجريبية
const reportData = {
  period: 'مارس ٢٠٢٤',
  totalSales: 45,
  totalRevenue: 156789.99,
  averageOrderValue: 3484.22,
  topProducts: [
    { productId: '1', productName: 'لابتوب ديل XPS', quantity: 15, revenue: 74999.85 },
    { productId: '2', productName: 'سماعات سوني', quantity: 30, revenue: 26999.70 }
  ],
  topCustomers: [
    { customerId: '1', customerName: 'محمد أحمد', purchases: 5, totalSpent: 25000 },
    { customerId: '2', customerName: 'سارة خالد', purchases: 3, totalSpent: 15000 }
  ]
};

function Reports() {
  const [period, setPeriod] = useState('شهري');

  return (
    <div className="p-8">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h2 className="text-2xl font-bold text-gray-800 mb-2">التقارير</h2>
          <p className="text-gray-600">تحليل المبيعات والأداء</p>
        </div>
        <div className="flex items-center gap-4">
          <Calendar className="w-5 h-5 text-gray-500" />
          <select
            value={period}
            onChange={(e) => setPeriod(e.target.value)}
            className="border border-gray-200 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-emerald-500"
          >
            <option value="يومي">يومي</option>
            <option value="أسبوعي">أسبوعي</option>
            <option value="شهري">شهري</option>
            <option value="سنوي">سنوي</option>
          </select>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        {[
          { title: 'إجمالي المبيعات', value: reportData.totalSales, unit: 'طلب' },
          { title: 'إجمالي الإيرادات', value: reportData.totalRevenue.toFixed(2), unit: 'ر.س' },
          { title: 'متوسط قيمة الطلب', value: reportData.averageOrderValue.toFixed(2), unit: 'ر.س' }
        ].map((stat, index) => (
          <div key={index} className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
            <h3 className="text-gray-600 text-sm mb-1">{stat.title}</h3>
            <p className="text-2xl font-bold text-gray-800">
              {stat.value} {stat.unit}
            </p>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-gray-800">تحليل المبيعات</h3>
            <BarChart className="w-5 h-5 text-gray-400" />
          </div>
          <SalesChart />
        </div>
        <TopProducts products={reportData.topProducts} />
      </div>

      <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
        <TopCustomers customers={reportData.topCustomers} />
      </div>
    </div>
  );
}

export default Reports;