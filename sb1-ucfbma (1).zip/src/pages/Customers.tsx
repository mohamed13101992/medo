import React, { useState } from 'react';
import { Plus, Search } from 'lucide-react';
import { Customer } from '../types';
import CustomerCard from '../components/customers/CustomerCard';
import CustomerForm from '../components/customers/CustomerForm';

// بيانات تجريبية
const initialCustomers: Customer[] = [
  {
    id: '1',
    name: 'محمد أحمد',
    email: 'mohammed@example.com',
    phone: '٠٥٠٠٠٠٠٠٠١',
    address: 'الرياض، حي النخيل',
    joinDate: '٢٠٢٤/٠٣/٠١',
    totalPurchases: 15000,
    status: 'نشط',
    notes: 'عميل مميز',
  },
  {
    id: '2',
    name: 'سارة خالد',
    email: 'sara@example.com',
    phone: '٠٥٠٠٠٠٠٠٠٢',
    address: 'جدة، حي الروضة',
    joinDate: '٢٠٢٤/٠٢/١٥',
    totalPurchases: 8500,
    status: 'نشط',
  },
  {
    id: '3',
    name: 'عبدالله محمد',
    email: 'abdullah@example.com',
    phone: '٠٥٠٠٠٠٠٠٠٣',
    address: 'الدمام، حي الشاطئ',
    joinDate: '٢٠٢٤/٠١/٢٠',
    totalPurchases: 12000,
    status: 'غير نشط',
    notes: 'بحاجة للمتابعة',
  },
];

function Customers() {
  const [customers, setCustomers] = useState<Customer[]>(initialCustomers);
  const [showForm, setShowForm] = useState(false);
  const [editingCustomer, setEditingCustomer] = useState<Customer | undefined>();
  const [searchQuery, setSearchQuery] = useState('');

  const handleAddCustomer = (customerData: Omit<Customer, 'id' | 'joinDate' | 'totalPurchases'>) => {
    const newCustomer: Customer = {
      ...customerData,
      id: Date.now().toString(),
      joinDate: new Date().toLocaleDateString('ar-SA'),
      totalPurchases: 0,
    };
    setCustomers((prev) => [...prev, newCustomer]);
  };

  const handleEditCustomer = (customerData: Omit<Customer, 'id' | 'joinDate' | 'totalPurchases'>) => {
    if (editingCustomer) {
      setCustomers((prev) =>
        prev.map((c) =>
          c.id === editingCustomer.id
            ? { ...customerData, id: c.id, joinDate: c.joinDate, totalPurchases: c.totalPurchases }
            : c
        )
      );
    }
  };

  const handleDeleteCustomer = (id: string) => {
    if (window.confirm('هل أنت متأكد من حذف هذا العميل؟')) {
      setCustomers((prev) => prev.filter((c) => c.id !== id));
    }
  };

  const filteredCustomers = customers.filter((customer) =>
    customer.name.includes(searchQuery) ||
    customer.email.includes(searchQuery) ||
    customer.phone.includes(searchQuery)
  );

  return (
    <div className="p-8">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h2 className="text-2xl font-bold text-gray-800 mb-2">العملاء</h2>
          <p className="text-gray-600">إدارة العملاء ومتابعة نشاطهم</p>
        </div>
        <button
          onClick={() => {
            setEditingCustomer(undefined);
            setShowForm(true);
          }}
          className="flex items-center gap-2 bg-emerald-600 text-white px-4 py-2 rounded-lg hover:bg-emerald-700"
        >
          <Plus className="w-5 h-5" />
          <span>إضافة عميل</span>
        </button>
      </div>

      <div className="mb-6 relative">
        <Search className="w-5 h-5 absolute right-3 top-1/2 -translate-y-1/2 text-gray-400" />
        <input
          type="text"
          placeholder="البحث عن عميل..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="w-full pr-10 pl-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-transparent"
        />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredCustomers.map((customer) => (
          <CustomerCard
            key={customer.id}
            customer={customer}
            onEdit={(customer) => {
              setEditingCustomer(customer);
              setShowForm(true);
            }}
            onDelete={handleDeleteCustomer}
          />
        ))}
      </div>

      {showForm && (
        <CustomerForm
          customer={editingCustomer}
          onSubmit={editingCustomer ? handleEditCustomer : handleAddCustomer}
          onClose={() => {
            setShowForm(false);
            setEditingCustomer(undefined);
          }}
        />
      )}
    </div>
  );
}

export default Customers;