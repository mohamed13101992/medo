import React, { useState } from 'react';
import { Plus, Filter } from 'lucide-react';
import { Sale } from '../types';
import SalesList from '../components/sales/SalesList';
import SaleForm from '../components/sales/SaleForm';

// بيانات تجريبية
const initialSales: Sale[] = [
  {
    id: '1',
    customerId: '1',
    customerName: 'محمد أحمد',
    items: [
      {
        productId: '1',
        productName: 'لابتوب ديل XPS',
        quantity: 1,
        unitPrice: 4999.99,
        total: 4999.99
      }
    ],
    subtotal: 4999.99,
    tax: 750,
    total: 5749.99,
    date: '٢٠٢٤/٠٣/١٥',
    status: 'مكتمل',
    paymentMethod: 'بطاقة ائتمان'
  },
  {
    id: '2',
    customerId: '2',
    customerName: 'سارة خالد',
    items: [
      {
        productId: '2',
        productName: 'سماعات سوني',
        quantity: 2,
        unitPrice: 899.99,
        total: 1799.98
      }
    ],
    subtotal: 1799.98,
    tax: 270,
    total: 2069.98,
    date: '٢٠٢٤/٠٣/١٤',
    status: 'مكتمل',
    paymentMethod: 'نقداً'
  }
];

function Sales() {
  const [sales, setSales] = useState<Sale[]>(initialSales);
  const [showForm, setShowForm] = useState(false);
  const [filterStatus, setFilterStatus] = useState<Sale['status'] | 'الكل'>('الكل');

  const handleAddSale = (saleData: Omit<Sale, 'id' | 'date' | 'subtotal' | 'tax' | 'total'>) => {
    const subtotal = saleData.items.reduce((acc, item) => acc + item.total, 0);
    const tax = subtotal * 0.15; // 15% ضريبة القيمة المضافة
    const total = subtotal + tax;

    const newSale: Sale = {
      ...saleData,
      id: Date.now().toString(),
      date: new Date().toLocaleDateString('ar-SA'),
      subtotal,
      tax,
      total
    };

    setSales((prev) => [newSale, ...prev]);
  };

  const filteredSales = filterStatus === 'الكل'
    ? sales
    : sales.filter(sale => sale.status === filterStatus);

  return (
    <div className="p-8">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h2 className="text-2xl font-bold text-gray-800 mb-2">المبيعات</h2>
          <p className="text-gray-600">إدارة المبيعات والفواتير</p>
        </div>
        <button
          onClick={() => setShowForm(true)}
          className="flex items-center gap-2 bg-emerald-600 text-white px-4 py-2 rounded-lg hover:bg-emerald-700"
        >
          <Plus className="w-5 h-5" />
          <span>إضافة مبيعة</span>
        </button>
      </div>

      <div className="mb-6 flex items-center gap-4">
        <div className="flex items-center gap-2">
          <Filter className="w-5 h-5 text-gray-500" />
          <select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value as Sale['status'] | 'الكل')}
            className="border border-gray-200 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-emerald-500"
          >
            <option value="الكل">جميع الحالات</option>
            <option value="مكتمل">مكتمل</option>
            <option value="معلق">معلق</option>
            <option value="ملغي">ملغي</option>
          </select>
        </div>
      </div>

      <SalesList sales={filteredSales} />

      {showForm && (
        <SaleForm
          onSubmit={handleAddSale}
          onClose={() => setShowForm(false)}
        />
      )}
    </div>
  );
}

export default Sales;