import React, { useState } from 'react';
import { Plus } from 'lucide-react';
import { Product } from '../types';
import ProductCard from '../components/products/ProductCard';
import ProductForm from '../components/products/ProductForm';

// بيانات تجريبية
const initialProducts: Product[] = [
  {
    id: '1',
    name: 'لابتوب ديل XPS',
    description: 'لابتوب احترافي للأعمال والتصميم',
    price: 4999.99,
    stock: 15,
    category: 'إلكترونيات',
    imageUrl: 'https://images.unsplash.com/photo-1593642632823-8f785ba67e45?auto=format&fit=crop&q=80',
  },
  {
    id: '2',
    name: 'سماعات سوني',
    description: 'سماعات لاسلكية مع خاصية إلغاء الضوضاء',
    price: 899.99,
    stock: 25,
    category: 'إلكترونيات',
    imageUrl: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&q=80',
  },
  {
    id: '3',
    name: 'ساعة ذكية',
    description: 'ساعة ذكية متعددة المزايا',
    price: 1299.99,
    stock: 30,
    category: 'إلكترونيات',
    imageUrl: 'https://images.unsplash.com/photo-1546868871-7041f2a55e12?auto=format&fit=crop&q=80',
  },
];

function Products() {
  const [products, setProducts] = useState<Product[]>(initialProducts);
  const [showForm, setShowForm] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | undefined>();

  const handleAddProduct = (productData: Omit<Product, 'id'>) => {
    const newProduct = {
      ...productData,
      id: Date.now().toString(),
    };
    setProducts((prev) => [...prev, newProduct]);
  };

  const handleEditProduct = (productData: Omit<Product, 'id'>) => {
    if (editingProduct) {
      setProducts((prev) =>
        prev.map((p) =>
          p.id === editingProduct.id ? { ...productData, id: p.id } : p
        )
      );
    }
  };

  const handleDeleteProduct = (id: string) => {
    if (window.confirm('هل أنت متأكد من حذف هذا المنتج؟')) {
      setProducts((prev) => prev.filter((p) => p.id !== id));
    }
  };

  return (
    <div className="p-8">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h2 className="text-2xl font-bold text-gray-800 mb-2">المنتجات</h2>
          <p className="text-gray-600">إدارة المنتجات والمخزون</p>
        </div>
        <button
          onClick={() => {
            setEditingProduct(undefined);
            setShowForm(true);
          }}
          className="flex items-center gap-2 bg-emerald-600 text-white px-4 py-2 rounded-lg hover:bg-emerald-700"
        >
          <Plus className="w-5 h-5" />
          <span>إضافة منتج</span>
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {products.map((product) => (
          <ProductCard
            key={product.id}
            product={product}
            onEdit={(product) => {
              setEditingProduct(product);
              setShowForm(true);
            }}
            onDelete={handleDeleteProduct}
          />
        ))}
      </div>

      {showForm && (
        <ProductForm
          product={editingProduct}
          onSubmit={editingProduct ? handleEditProduct : handleAddProduct}
          onClose={() => {
            setShowForm(false);
            setEditingProduct(undefined);
          }}
        />
      )}
    </div>
  );
}

export default Products;