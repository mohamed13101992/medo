import React from 'react';
import { TrendingUp, Users, Package, DollarSign } from 'lucide-react';
import StatsCard from '../components/dashboard/StatsCard';
import RecentTransactions from '../components/dashboard/RecentTransactions';
import SalesChart from '../components/dashboard/SalesChart';

const stats = [
  { icon: DollarSign, title: 'إجمالي المبيعات', value: '٤٥,٦٧٨ ر.س', change: '+١٢٪' },
  { icon: Package, title: 'المنتجات', value: '١,٢٣٤', change: '+٥٪' },
  { icon: Users, title: 'العملاء النشطين', value: '٨٩٢', change: '+٨٪' },
  { icon: TrendingUp, title: 'معدل النمو', value: '٢٣٪', change: '+١٥٪' },
];

function Dashboard() {
  return (
    <div className="p-8">
      <div className="mb-8">
        <h2 className="text-2xl font-bold text-gray-800 mb-4">مرحباً بك في لوحة التحكم</h2>
        <p className="text-gray-600">نظرة عامة على أداء مبيعاتك</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {stats.map((stat, index) => (
          <StatsCard key={index} {...stat} />
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
          <h3 className="text-lg font-semibold text-gray-800 mb-4">تحليل المبيعات</h3>
          <SalesChart />
        </div>
        <RecentTransactions />
      </div>
    </div>
  );
}

export default Dashboard;