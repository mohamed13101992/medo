import React from 'react';
import { NavLink } from 'react-router-dom';
import { LayoutDashboard, ShoppingCart, Users, Package, Settings, BarChart3 } from 'lucide-react';

const menuItems = [
  { icon: LayoutDashboard, text: 'لوحة التحكم', path: '/' },
  { icon: ShoppingCart, text: 'المبيعات', path: '/sales' },
  { icon: Users, text: 'العملاء', path: '/customers' },
  { icon: Package, text: 'المنتجات', path: '/products' },
  { icon: BarChart3, text: 'التقارير', path: '/reports' },
  { icon: Settings, text: 'الإعدادات', path: '/settings' },
];

function Sidebar() {
  return (
    <aside className="w-64 bg-white shadow-lg flex-shrink-0">
      <div className="p-4">
        <h1 className="text-2xl font-bold text-emerald-600 text-center mb-8">نظام المبيعات</h1>
        <nav className="space-y-1">
          {menuItems.map((item, index) => (
            <NavLink
              key={index}
              to={item.path}
              className={({ isActive }) =>
                `flex items-center space-x-2 space-x-reverse w-full p-3 rounded-lg transition-colors mb-1 ${
                  isActive
                    ? 'bg-emerald-50 text-emerald-600'
                    : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'
                }`
              }
            >
              <item.icon className="w-5 h-5" />
              <span>{item.text}</span>
            </NavLink>
          ))}
        </nav>
      </div>
    </aside>
  );
}

export default Sidebar;