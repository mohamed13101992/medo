import React from 'react';

function RecentTransactions() {
  const transactions = [
    { id: 1001, time: '١', amount: '٧٨٩' },
    { id: 1002, time: '٢', amount: '١,٢٣٤' },
    { id: 1003, time: '٣', amount: '٩٥٦' },
    { id: 1004, time: '٤', amount: '٢,٣٤٥' },
  ];

  return (
    <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
      <h3 className="text-lg font-semibold text-gray-800 mb-4">أحدث المعاملات</h3>
      <div className="space-y-4">
        {transactions.map((transaction) => (
          <div key={transaction.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
            <div>
              <p className="font-medium text-gray-800">طلب #{transaction.id}</p>
              <p className="text-sm text-gray-600">قبل {transaction.time} ساعات</p>
            </div>
            <span className="text-emerald-600 font-medium">{transaction.amount} ر.س</span>
          </div>
        ))}
      </div>
    </div>
  );
}

export default RecentTransactions;