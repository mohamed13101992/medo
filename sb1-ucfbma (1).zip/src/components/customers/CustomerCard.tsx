import React from 'react';
import { Edit, Trash2, Phone, Mail, MapPin } from 'lucide-react';
import { Customer } from '../../types';

interface CustomerCardProps {
  customer: Customer;
  onEdit: (customer: Customer) => void;
  onDelete: (id: string) => void;
}

function CustomerCard({ customer, onEdit, onDelete }: CustomerCardProps) {
  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-100 p-6">
      <div className="flex justify-between items-start mb-4">
        <div>
          <h3 className="text-lg font-semibold text-gray-800">{customer.name}</h3>
          <span className={`inline-block mt-1 px-3 py-1 rounded-full text-sm ${
            customer.status === 'نشط' 
              ? 'bg-emerald-50 text-emerald-600' 
              : 'bg-gray-100 text-gray-600'
          }`}>
            {customer.status}
          </span>
        </div>
        <div className="flex gap-2">
          <button
            onClick={() => onEdit(customer)}
            className="p-2 text-gray-600 hover:text-emerald-600 hover:bg-emerald-50 rounded-lg transition-colors"
          >
            <Edit className="w-5 h-5" />
          </button>
          <button
            onClick={() => onDelete(customer.id)}
            className="p-2 text-gray-600 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"
          >
            <Trash2 className="w-5 h-5" />
          </button>
        </div>
      </div>

      <div className="space-y-3">
        <div className="flex items-center gap-2 text-gray-600">
          <Phone className="w-4 h-4" />
          <span className="text-sm">{customer.phone}</span>
        </div>
        <div className="flex items-center gap-2 text-gray-600">
          <Mail className="w-4 h-4" />
          <span className="text-sm">{customer.email}</span>
        </div>
        <div className="flex items-center gap-2 text-gray-600">
          <MapPin className="w-4 h-4" />
          <span className="text-sm">{customer.address}</span>
        </div>
      </div>

      <div className="mt-4 pt-4 border-t border-gray-100">
        <div className="flex justify-between text-sm">
          <span className="text-gray-600">تاريخ الانضمام:</span>
          <span className="text-gray-800">{customer.joinDate}</span>
        </div>
        <div className="flex justify-between text-sm mt-2">
          <span className="text-gray-600">إجمالي المشتريات:</span>
          <span className="text-emerald-600 font-semibold">{customer.totalPurchases} ر.س</span>
        </div>
      </div>

      {customer.notes && (
        <div className="mt-4 pt-4 border-t border-gray-100">
          <p className="text-sm text-gray-600">{customer.notes}</p>
        </div>
      )}
    </div>
  );
}

export default CustomerCard;