import React from 'react';
import { LayoutDashboard, ShoppingCart, Users, Package, Settings, BarChart3 } from 'lucide-react';

const menuItems = [
  { icon: LayoutDashboard, text: 'لوحة التحكم' },
  { icon: ShoppingCart, text: 'المبيعات' },
  { icon: Users, text: 'العملاء' },
  { icon: Package, text: 'المنتجات' },
  { icon: BarChart3, text: 'التقارير' },
  { icon: Settings, text: 'الإعدادات' },
];

function Sidebar() {
  return (
    <aside className="w-64 bg-white shadow-lg">
      <div className="p-4">
        <h1 className="text-2xl font-bold text-emerald-600 text-center mb-8">نظام المبيعات</h1>
        <nav>
          {menuItems.map((item, index) => (
            <button
              key={index}
              className="flex items-center space-x-2 space-x-reverse w-full p-3 rounded-lg text-gray-600 hover:bg-emerald-50 hover:text-emerald-600 transition-colors mb-1"
            >
              <item.icon className="w-5 h-5" />
              <span>{item.text}</span>
            </button>
          ))}
        </nav>
      </div>
    </aside>
  );
}

export default Sidebar;