import React from 'react';
import { TrendingUp, Users, Package, DollarSign } from 'lucide-react';
import SalesChart from './SalesChart';

const stats = [
  { icon: DollarSign, title: 'إجمالي المبيعات', value: '٤٥,٦٧٨ ر.س', change: '+١٢٪' },
  { icon: Package, title: 'المنتجات', value: '١,٢٣٤', change: '+٥٪' },
  { icon: Users, title: 'العملاء النشطين', value: '٨٩٢', change: '+٨٪' },
  { icon: TrendingUp, title: 'معدل النمو', value: '٢٣٪', change: '+١٥٪' },
];

function Dashboard() {
  return (
    <div className="p-8">
      <div className="mb-8">
        <h2 className="text-2xl font-bold text-gray-800 mb-4">مرحباً بك في لوحة التحكم</h2>
        <p className="text-gray-600">نظرة عامة على أداء مبيعاتك</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {stats.map((stat, index) => (
          <div key={index} className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
            <div className="flex items-center justify-between mb-4">
              <div className="bg-emerald-100 p-3 rounded-lg">
                <stat.icon className="w-6 h-6 text-emerald-600" />
              </div>
              <span className="text-sm font-medium text-emerald-600 bg-emerald-50 px-2.5 py-0.5 rounded-full">
                {stat.change}
              </span>
            </div>
            <h3 className="text-gray-600 text-sm mb-1">{stat.title}</h3>
            <p className="text-2xl font-bold text-gray-800">{stat.value}</p>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
          <h3 className="text-lg font-semibold text-gray-800 mb-4">تحليل المبيعات</h3>
          <SalesChart />
        </div>
        
        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
          <h3 className="text-lg font-semibold text-gray-800 mb-4">أحدث المعاملات</h3>
          <div className="space-y-4">
            {[1, 2, 3, 4].map((_, index) => (
              <div key={index} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                <div>
                  <p className="font-medium text-gray-800">طلب #{١٠٠٠ + index}</p>
                  <p className="text-sm text-gray-600">قبل {index + 1} ساعات</p>
                </div>
                <span className="text-emerald-600 font-medium">٧٨٩ ر.س</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

export default Dashboard;