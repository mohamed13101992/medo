import React from 'react';
import { Package } from 'lucide-react';

interface TopProductsProps {
  products: {
    productId: string;
    productName: string;
    quantity: number;
    revenue: number;
  }[];
}

function TopProducts({ products }: TopProductsProps) {
  return (
    <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold text-gray-800">المنتجات الأكثر مبيعاً</h3>
        <Package className="w-5 h-5 text-gray-400" />
      </div>
      <div className="space-y-4">
        {products.map((product) => (
          <div
            key={product.productId}
            className="flex items-center justify-between p-4 bg-gray-50 rounded-lg"
          >
            <div>
              <p className="font-medium text-gray-800">{product.productName}</p>
              <p className="text-sm text-gray-600">الكمية المباعة: {product.quantity}</p>
            </div>
            <span className="text-emerald-600 font-medium">{product.revenue.toFixed(2)} ر.س</span>
          </div>
        ))}
      </div>
    </div>
  );
}

export default TopProducts;