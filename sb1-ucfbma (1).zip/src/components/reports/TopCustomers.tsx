import React from 'react';
import { Users } from 'lucide-react';

interface TopCustomersProps {
  customers: {
    customerId: string;
    customerName: string;
    purchases: number;
    totalSpent: number;
  }[];
}

function TopCustomers({ customers }: TopCustomersProps) {
  return (
    <div>
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold text-gray-800">العملاء الأكثر شراءً</h3>
        <Users className="w-5 h-5 text-gray-400" />
      </div>
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead>
            <tr className="bg-gray-50">
              <th className="px-6 py-3 text-right text-sm font-medium text-gray-500">العميل</th>
              <th className="px-6 py-3 text-right text-sm font-medium text-gray-500">عدد المشتريات</th>
              <th className="px-6 py-3 text-right text-sm font-medium text-gray-500">إجمالي الإنفاق</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-100">
            {customers.map((customer) => (
              <tr key={customer.customerId} className="hover:bg-gray-50">
                <td className="px-6 py-4 text-sm font-medium text-gray-900">
                  {customer.customerName}
                </td>
                <td className="px-6 py-4 text-sm text-gray-500">
                  {customer.purchases} طلب
                </td>
                <td className="px-6 py-4 text-sm text-emerald-600 font-medium">
                  {customer.totalSpent.toFixed(2)} ر.س
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export default TopCustomers;