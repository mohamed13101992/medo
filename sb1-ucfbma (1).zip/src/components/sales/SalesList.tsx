import React from 'react';
import { Sale } from '../../types';
import { FileText, ChevronDown } from 'lucide-react';

interface SalesListProps {
  sales: Sale[];
}

function SalesList({ sales }: SalesListProps) {
  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-100">
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead>
            <tr className="bg-gray-50">
              <th className="px-6 py-3 text-right text-sm font-medium text-gray-500">رقم الفاتورة</th>
              <th className="px-6 py-3 text-right text-sm font-medium text-gray-500">العميل</th>
              <th className="px-6 py-3 text-right text-sm font-medium text-gray-500">التاريخ</th>
              <th className="px-6 py-3 text-right text-sm font-medium text-gray-500">المبلغ</th>
              <th className="px-6 py-3 text-right text-sm font-medium text-gray-500">الحالة</th>
              <th className="px-6 py-3 text-right text-sm font-medium text-gray-500">طريقة الدفع</th>
              <th className="px-6 py-3 text-right text-sm font-medium text-gray-500"></th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-100">
            {sales.map((sale) => (
              <tr key={sale.id} className="hover:bg-gray-50">
                <td className="px-6 py-4 text-sm text-gray-900">
                  <div className="flex items-center gap-2">
                    <FileText className="w-4 h-4 text-gray-400" />
                    #{sale.id}
                  </div>
                </td>
                <td className="px-6 py-4 text-sm text-gray-900">{sale.customerName}</td>
                <td className="px-6 py-4 text-sm text-gray-500">{sale.date}</td>
                <td className="px-6 py-4 text-sm font-medium text-gray-900">{sale.total.toFixed(2)} ر.س</td>
                <td className="px-6 py-4">
                  <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                    sale.status === 'مكتمل'
                      ? 'bg-green-100 text-green-800'
                      : sale.status === 'معلق'
                      ? 'bg-yellow-100 text-yellow-800'
                      : 'bg-red-100 text-red-800'
                  }`}>
                    {sale.status}
                  </span>
                </td>
                <td className="px-6 py-4 text-sm text-gray-500">{sale.paymentMethod}</td>
                <td className="px-6 py-4 text-sm text-gray-500">
                  <button className="text-gray-400 hover:text-gray-500">
                    <ChevronDown className="w-5 h-5" />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export default SalesList;