import React, { useState, useEffect } from 'react';
import { X, Plus, Trash2 } from 'lucide-react';
import { Sale, SaleFormData, Product, Customer } from '../../types';

interface SaleFormProps {
  onSubmit: (data: Omit<Sale, 'id' | 'date' | 'subtotal' | 'tax' | 'total'>) => void;
  onClose: () => void;
}

// بيانات تجريبية للمنتجات والعملاء
const demoProducts: Product[] = [
  {
    id: '1',
    name: 'لابتوب ديل XPS',
    description: '',
    price: 4999.99,
    stock: 15,
    category: 'إلكترونيات',
    imageUrl: ''
  },
  {
    id: '2',
    name: 'سماعات سوني',
    description: '',
    price: 899.99,
    stock: 25,
    category: 'إلكترونيات',
    imageUrl: ''
  }
];

const demoCustomers: Customer[] = [
  {
    id: '1',
    name: 'محمد أحمد',
    email: 'mohammed@example.com',
    phone: '٠٥٠٠٠٠٠٠٠١',
    address: 'الرياض',
    joinDate: '',
    totalPurchases: 0,
    status: 'نشط'
  },
  {
    id: '2',
    name: 'سارة خالد',
    email: 'sara@example.com',
    phone: '٠٥٠٠٠٠٠٠٠٢',
    address: 'جدة',
    joinDate: '',
    totalPurchases: 0,
    status: 'نشط'
  }
];

const initialFormData: SaleFormData = {
  customerId: '',
  items: [],
  paymentMethod: 'نقداً',
  notes: ''
};

function SaleForm({ onSubmit, onClose }: SaleFormProps) {
  const [formData, setFormData] = useState<SaleFormData>(initialFormData);

  const handleAddItem = () => {
    setFormData(prev => ({
      ...prev,
      items: [...prev.items, { productId: '', productName: '', quantity: 1, unitPrice: 0 }]
    }));
  };

  const handleRemoveItem = (index: number) => {
    setFormData(prev => ({
      ...prev,
      items: prev.items.filter((_, i) => i !== index)
    }));
  };

  const handleItemChange = (index: number, field: string, value: string | number) => {
    setFormData(prev => ({
      ...prev,
      items: prev.items.map((item, i) => {
        if (i === index) {
          if (field === 'productId') {
            const product = demoProducts.find(p => p.id === value);
            return {
              ...item,
              [field]: value,
              productName: product?.name || '',
              unitPrice: product?.price || 0
            };
          }
          return { ...item, [field]: value };
        }
        return item;
      })
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const customer = demoCustomers.find(c => c.id === formData.customerId);
    if (!customer) return;

    const saleData = {
      ...formData,
      customerName: customer.name,
      items: formData.items.map(item => ({
        ...item,
        total: item.quantity * item.unitPrice
      })),
      status: 'مكتمل' as const
    };

    onSubmit(saleData);
    onClose();
  };

  const calculateTotal = () => {
    return formData.items.reduce((acc, item) => acc + (item.quantity * item.unitPrice), 0);
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg w-full max-w-4xl p-6 relative max-h-[90vh] overflow-y-auto">
        <button
          onClick={onClose}
          className="absolute left-4 top-4 p-2 hover:bg-gray-100 rounded-full"
        >
          <X className="w-5 h-5" />
        </button>
        
        <h2 className="text-xl font-semibold mb-6">إضافة مبيعة جديدة</h2>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              العميل
            </label>
            <select
              value={formData.customerId}
              onChange={(e) => setFormData(prev => ({ ...prev, customerId: e.target.value }))}
              className="w-full p-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-transparent"
              required
            >
              <option value="">اختر العميل</option>
              {demoCustomers.map(customer => (
                <option key={customer.id} value={customer.id}>
                  {customer.name}
                </option>
              ))}
            </select>
          </div>

          <div>
            <div className="flex justify-between items-center mb-2">
              <label className="block text-sm font-medium text-gray-700">
                المنتجات
              </label>
              <button
                type="button"
                onClick={handleAddItem}
                className="flex items-center gap-1 text-sm text-emerald-600 hover:text-emerald-700"
              >
                <Plus className="w-4 h-4" />
                إضافة منتج
              </button>
            </div>

            <div className="space-y-4">
              {formData.items.map((item, index) => (
                <div key={index} className="flex gap-4 items-start">
                  <div className="flex-1">
                    <select
                      value={item.productId}
                      onChange={(e) => handleItemChange(index, 'productId', e.target.value)}
                      className="w-full p-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-transparent"
                      required
                    >
                      <option value="">اختر المنتج</option>
                      {demoProducts.map(product => (
                        <option key={product.id} value={product.id}>
                          {product.name} - {product.price} ر.س
                        </option>
                      ))}
                    </select>
                  </div>
                  <div className="w-24">
                    <input
                      type="number"
                      value={item.quantity}
                      onChange={(e) => handleItemChange(index, 'quantity', parseInt(e.target.value))}
                      min="1"
                      className="w-full p-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-transparent"
                      required
                    />
                  </div>
                  <button
                    type="button"
                    onClick={() => handleRemoveItem(index)}
                    className="p-2 text-gray-400 hover:text-red-500"
                  >
                    <Trash2 className="w-5 h-5" />
                  </button>
                </div>
              ))}
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              طريقة الدفع
            </label>
            <select
              value={formData.paymentMethod}
              onChange={(e) => setFormData(prev => ({ ...prev, paymentMethod: e.target.value as Sale['paymentMethod'] }))}
              className="w-full p-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-transparent"
              required
            >
              <option value="نقداً">نقداً</option>
              <option value="بطاقة ائتمان">بطاقة ائتمان</option>
              <option value="تحويل بنكي">تحويل بنكي</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              ملاحظات
            </label>
            <textarea
              value={formData.notes}
              onChange={(e) => setFormData(prev => ({ ...prev, notes: e.target.value }))}
              className="w-full p-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-transparent"
              rows={3}
            />
          </div>

          <div className="border-t pt-4">
            <div className="flex justify-between items-center text-lg font-medium">
              <span>الإجمالي:</span>
              <span className="text-emerald-600">{calculateTotal().toFixed(2)} ر.س</span>
            </div>
          </div>

          <div className="flex justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-gray-600 hover:bg-gray-100 rounded-lg"
            >
              إلغاء
            </button>
            <button
              type="submit"
              className="px-4 py-2 bg-emerald-600 text-white rounded-lg hover:bg-emerald-700"
            >
              إتمام البيع
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

export default SaleForm;