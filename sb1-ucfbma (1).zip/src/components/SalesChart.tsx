import React from 'react';

function SalesChart() {
  return (
    <div className="h-[300px] flex items-center justify-center bg-gray-50 rounded-lg">
      <p className="text-gray-500">رسم بياني للمبيعات سيتم إضافته هنا</p>
    </div>
  );
}

export default SalesChart;